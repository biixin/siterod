export const chatConfig = {
  attendantName: 'Ana',
  attendantImage: 'https://console-typebot-minio.kjufc9.easypanel.host/api/v1/buckets/hot-mj/objects/download?preview=true&prefix=whatsapp-222.jpg&version_id=null',
  attendantAvatar: 'https://media-wordpress.kjufc9.easypanel.host/wp-content/uploads/2025/10/majoblonde_3723240941839833017s2025-10-6-13.50.791-story-2.jpg',
  chatBackground: 'https://console-typebot-minio.kjufc9.easypanel.host/api/v1/buckets/hot-mj/objects/download?preview=true&prefix=whatsapp.jpg&version_id=null'
};
